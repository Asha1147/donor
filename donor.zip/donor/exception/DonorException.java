package com.cg.donor.exception;

public class DonorException extends Exception{

	public DonorException(String message) {
		super(message);
		
	}
	
	

}
